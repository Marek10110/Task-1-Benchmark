package org.example;

import org.example.MatrixMultiplication;
import org.openjdk.jmh.annotations.*;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.Random;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@Fork(1)
public class MatrixMultiplicationBenchmarking {

	@State(Scope.Thread)
	public static class Operands {
		private final int n = 512;
		private final double[][] a = new double[n][n];
		private final double[][] b = new double[n][n];

		@Setup
		public void setup() {
			Random random = new Random();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					a[i][j] = random.nextDouble();
					b[i][j] = random.nextDouble();
				}
			}
		}
	}

	@State(Scope.Thread)
	public static class ResourceUsage {
		long totalMemoryUsed = 0;
		long totalCpuTimeUsed = 0;
		long totalElapsedTime = 0;
		int iterations = 0;

		public void accumulate(long memoryUsed, long cpuTimeUsed, long elapsedTime) {

			totalMemoryUsed += memoryUsed;
			totalCpuTimeUsed += cpuTimeUsed;
			totalElapsedTime += elapsedTime;
			iterations++;
		}

		@TearDown
		public void printAverages() {
			if (iterations > 0) {
				double averageMemoryUsageMB = (double) totalMemoryUsed / (1024 * 1024);
				double averageCpuTimeUsed = (double) totalCpuTimeUsed / iterations;
				double averageElapsedTime = (double) totalElapsedTime / iterations;


				double cpuUsagePercentage = 0;
				if (averageElapsedTime > 0) {
					cpuUsagePercentage = (totalCpuTimeUsed / (averageElapsedTime * 1_000_000)) * 100;
				}


				String cpuUsageFormatted = String.format("%.2f", cpuUsagePercentage);

				System.out.println("Average Memory Usage: " + averageMemoryUsageMB + " MB");
				System.out.println("Average CPU Time Used: " + averageCpuTimeUsed + " ms");
				System.out.println("CPU Usage Percentage: " + cpuUsageFormatted + " %");
			}
		}

	}

	@Warmup(iterations = 1, time = 1, timeUnit = TimeUnit.MILLISECONDS)
	@Benchmark
	public void multiplication(Operands operands, ResourceUsage resourceUsage) {
		long beforeUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

		ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
		long beforeCpuTime = threadMXBean.getCurrentThreadCpuTime();
		long startTime = System.nanoTime();

		new MatrixMultiplication().execute(operands.a, operands.b);

		long afterUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long afterCpuTime = threadMXBean.getCurrentThreadCpuTime();
		long endTime = System.nanoTime();

		long memoryUsed = afterUsedMem - beforeUsedMem;
		long cpuTimeUsed = (afterCpuTime - beforeCpuTime) / 1_000_000; 
		long elapsedTime = endTime - startTime;

		resourceUsage.accumulate(memoryUsed, cpuTimeUsed, elapsedTime);
	}
}
