import random
import psutil
from memory_profiler import memory_usage

def multiply_matrices(A, B):
    result = [[0] * len(B[0]) for _ in range(len(A))]
    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):
                result[i][j] += A[i][k] * B[k][j]
    return result

def create_matrix(size):
    return [[random.randint(1, 100) for _ in range(size)] for _ in range(size)]

def measure_memory(func, *args):
    mem_usages = []
    for _ in range(5):
        mem_usage = memory_usage((func, args), max_usage=True)
        mem_usages.append(mem_usage)
    return sum(mem_usages) / len(mem_usages)

def measure_cpu(func, *args):
    cpu_usages = []
    for _ in range(5):
        psutil.cpu_percent(interval=0.1)
        func(*args)
        cpu_usages.append(psutil.cpu_percent())
    return sum(cpu_usages) / len(cpu_usages)

def test_matrix_multiplication(benchmark):
    size = 512
    A = create_matrix(size)
    B = create_matrix(size)
    
    def wrapper():
        memory_diff = measure_memory(multiply_matrices, A, B)
        cpu_diff = measure_cpu(multiply_matrices, A, B)
        print(f"Average memory usage: {memory_diff:.4f} MiB")
        print(f"Average CPU usage: {cpu_diff:.4f}%")
        return multiply_matrices(A, B)
    
    benchmark(wrapper)
