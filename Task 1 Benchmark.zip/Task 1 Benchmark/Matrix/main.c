#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <matrixClass.h>
#include <windows.h>
#include <psapi.h>

double getCPUTime(){
    FILETIME creationTime, exitTime, kernelTime, userTime;
    if (GetProcessTimes(GetCurrentProcess(), &creationTime, &exitTime, &kernelTime, &userTime)) {
        ULARGE_INTEGER uTime;
        uTime.LowPart = userTime.dwLowDateTime;
        uTime.HighPart = userTime.dwHighDateTime;
        return uTime.QuadPart / 10000000.0;
    }
    return 0;
}

double getMemoryUsage(){
    PROCESS_MEMORY_COUNTERS memCounter;
    if (GetProcessMemoryInfo(GetCurrentProcess(), &memCounter, sizeof(memCounter))) {
        return (double)memCounter.WorkingSetSize / 1024.0;
    }
    return 0;
}
double getCPUUsagePercentage(){
    FILETIME idleTime, kernelTime, userTime;
    if (GetSystemTimes(&idleTime, &kernelTime, &userTime)) {
        ULARGE_INTEGER sysKernel, sysUser, sysIdle;
        sysKernel.LowPart = kernelTime.dwLowDateTime;
        sysKernel.HighPart = kernelTime.dwHighDateTime;
        sysUser.LowPart = userTime.dwLowDateTime;
        sysUser.HighPart = userTime.dwHighDateTime;
        sysIdle.LowPart = idleTime.dwLowDateTime;
        sysIdle.HighPart = idleTime.dwHighDateTime;

        ULONGLONG sysTotal = (sysKernel.QuadPart + sysUser.QuadPart);
        ULONGLONG sysActive = sysTotal - sysIdle.QuadPart;

        return (double)sysActive / (double)sysTotal * 100.0;
    }
    return 0.0;
}

void multiply_matrices(float **a, float **b, float **result, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            result[i][j] = 0;
            for (int k = 0; k < size; k++) {
                result[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}

void print_matrix(float **matrix, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            printf("%f ", matrix[i][j]);
        }
        printf("\n");
    }
}

float** create_matrix(int size) {
    float **matrix = (float **)malloc(size * sizeof(float *));
    for (int i = 0; i < size; i++) {
        matrix[i] = (float *)malloc(size * sizeof(float));
    }
    return matrix;
}

void fill_matrix_random(float **matrix, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            matrix[i][j] = (float)rand() / (float)(RAND_MAX) * 10.0;
        }
    }
}

void free_matrix(float **matrix, int size) {
    for (int i = 0; i < size; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

double matrixTime(int size, double *memoryUsage, double *cpuUsage){
    float **a = create_matrix(size);
    float **b = create_matrix(size);
    float **result = create_matrix(size);

    fill_matrix_random(a, size);
    fill_matrix_random(b, size);

    clock_t start, end;
    double cpu_time_used;

    double startCPU = getCPUTime();
    *memoryUsage = getMemoryUsage();

    start = clock();

    multiply_matrices(a, b, result, size);

    end = clock();
    double endCPU = getCPUTime();
    *memoryUsage = getMemoryUsage();

    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
    *cpuUsage = endCPU - startCPU;

    free_matrix(a, size);
    free_matrix(b, size);
    free_matrix(result, size);

    return cpu_time_used;
}

int main() {
    while(1){
        int size;
        printf("Enter matrix size: ");
        scanf("%d", &size);
        if(!size)break;

        srand(time(NULL));

        double memoryUsage = 0, cpuUsage = 0;
        double calcTime = matrixTime(size, &memoryUsage, &cpuUsage);
        double cpuUsagePercentage = getCPUUsagePercentage();

        printf("Matrix multiplication time: %.3f seconds\n", calcTime);
        printf("Memory usage: %.2f KB\n", memoryUsage);
        printf("CPU time: %.4f seconds\n", cpuUsage);
        printf("CPU usage: %.2f%%\n", cpuUsagePercentage);

        matrixTimeClass matrix;
        initMatrixClass(&matrix, size);
        addCountingTime(&matrix, calcTime, memoryUsage, cpuUsagePercentage);
        saveToFile(&matrix);
        printMatrixTimeClass(&matrix);
    }

    return 0;
}
