#ifndef MATRIXCLASS_H
#define MATRIXCLASS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int matrixSize;
    double *countingTimes;
    int size;
    double average;
    double min;
    double max;
    double mediana;
    char filename[30];

    double *memoryUsages;
    double *cpuUsages;
    double avgMemoryUsage;
    double avgCPUUsage;
} matrixTimeClass;

void loadFromFile(matrixTimeClass *matrix);
void updateAverage(matrixTimeClass *matrix);
void updateMediana(matrixTimeClass *matrix);
void updateMin(matrixTimeClass *matrix);
void updateMax(matrixTimeClass *matrix);

void initMatrixClass(matrixTimeClass *matrix, int matrixSize) {
    matrix->matrixSize = matrixSize;
    matrix->countingTimes = NULL;
    matrix->size = 0;
    matrix->min = 0;
    matrix->max = 0;
    matrix->mediana = 0;

    matrix->memoryUsages = NULL;
    matrix->cpuUsages = NULL;
    matrix->avgMemoryUsage = 0;
    matrix->avgCPUUsage = 0;

    snprintf(matrix->filename, sizeof(matrix->filename), "matrixTimeClass%d.txt", matrixSize);

    FILE *file = fopen(matrix->filename, "rb");
    if (file != NULL) {
        loadFromFile(matrix);
    }
    fclose(file);
}

void addCountingTime(matrixTimeClass *matrix, double time, double memoryUsage, double cpuUsage) {
    double *tempTime = (double *)realloc(matrix->countingTimes, (matrix->size + 1) * sizeof(double));
    double *tempMemory = (double *)realloc(matrix->memoryUsages, (matrix->size + 1) * sizeof(double));
    double *tempCPU = (double *)realloc(matrix->cpuUsages, (matrix->size + 1) * sizeof(double));

    if (tempTime == NULL || tempMemory == NULL || tempCPU == NULL) {
        printf("Memory allocation error.\n");
        return;
    }

    matrix->countingTimes = tempTime;
    matrix->memoryUsages = tempMemory;
    matrix->cpuUsages = tempCPU;

    matrix->countingTimes[matrix->size] = time;
    matrix->memoryUsages[matrix->size] = memoryUsage;
    matrix->cpuUsages[matrix->size] = cpuUsage;
    matrix->size++;

    if (matrix->size == 1) {
        matrix->average = time;
        matrix->min = time;
        matrix->max = time;
        matrix->mediana = time;
        matrix->avgMemoryUsage = memoryUsage;
        matrix->avgCPUUsage = cpuUsage;
    } else {
        updateAverage(matrix);
        updateMediana(matrix);
        updateMin(matrix);
        updateMax(matrix);

        matrix->avgMemoryUsage = (matrix->avgMemoryUsage * (matrix->size - 1) + memoryUsage) / matrix->size;
        matrix->avgCPUUsage = (matrix->avgCPUUsage * (matrix->size - 1) + cpuUsage) / matrix->size;
    }
}

void updateAverage(matrixTimeClass *matrix) {
    double newAverage = 0;
    for (int i = 0; i < matrix->size; i++) {
        newAverage += matrix->countingTimes[i];
    }
    matrix->average = newAverage / matrix->size;
}

void updateMediana(matrixTimeClass *matrix) {
    int size = matrix->size;
    double sortedTable[size];

    for (int i = 0; i < size; i++) {
        sortedTable[i] = matrix->countingTimes[i];
    }

    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (sortedTable[j] > sortedTable[j + 1]) {
                double temp = sortedTable[j];
                sortedTable[j] = sortedTable[j + 1];
                sortedTable[j + 1] = temp;
            }
        }
    }

    if (size % 2 == 0) {
        matrix->mediana = (sortedTable[size / 2 - 1] + sortedTable[size / 2]) / 2.0;
    } else {
        matrix->mediana = sortedTable[size / 2];
    }
}

void updateMin(matrixTimeClass *matrix) {
    matrix->min = matrix->countingTimes[0];
    for (int i = 1; i < matrix->size; i++) {
        if (matrix->countingTimes[i] < matrix->min) {
            matrix->min = matrix->countingTimes[i];
        }
    }
}

void updateMax(matrixTimeClass *matrix) {
    matrix->max = matrix->countingTimes[0];
    for (int i = 1; i < matrix->size; i++) {
        if (matrix->countingTimes[i] > matrix->max) {
            matrix->max = matrix->countingTimes[i];
        }
    }
}

void saveToFile(const matrixTimeClass *matrix) {
    FILE *file = fopen(matrix->filename, "wb");
    if (!file) {
        printf("File opening error.\n");
        return;
    }
    fwrite(&matrix->matrixSize, sizeof(matrix->matrixSize), 1, file);
    fwrite(&matrix->size, sizeof(matrix->size), 1, file);
    fwrite(&matrix->average, sizeof(matrix->average), 1, file);
    fwrite(&matrix->min, sizeof(matrix->min), 1, file);
    fwrite(&matrix->max, sizeof(matrix->max), 1, file);
    fwrite(&matrix->mediana, sizeof(matrix->mediana), 1, file);
    fwrite(&matrix->avgMemoryUsage, sizeof(matrix->avgMemoryUsage), 1, file);
    fwrite(&matrix->avgCPUUsage, sizeof(matrix->avgCPUUsage), 1, file);

    fwrite(matrix->memoryUsages, sizeof(double), matrix->size, file);
    fwrite(matrix->cpuUsages, sizeof(double), matrix->size, file);
    fwrite(matrix->countingTimes, sizeof(double), matrix->size, file);

    fclose(file);
}

void loadFromFile(matrixTimeClass *matrix) {
    FILE *file = fopen(matrix->filename, "rb");
    if (file != NULL) {
        fread(&matrix->matrixSize, sizeof(matrix->matrixSize), 1, file);
        fread(&matrix->size, sizeof(matrix->size), 1, file);
        fread(&matrix->average, sizeof(matrix->average), 1, file);
        fread(&matrix->min, sizeof(matrix->min), 1, file);
        fread(&matrix->max, sizeof(matrix->max), 1, file);
        fread(&matrix->mediana, sizeof(matrix->mediana), 1, file);
        fread(&matrix->avgMemoryUsage, sizeof(matrix->avgMemoryUsage), 1, file);
        fread(&matrix->avgCPUUsage, sizeof(matrix->avgCPUUsage), 1, file);

        free(matrix->memoryUsages);
        matrix->memoryUsages = (double *)malloc(matrix->size * sizeof(double));
        fread(matrix->memoryUsages, sizeof(double), matrix->size, file);

        free(matrix->cpuUsages);
        matrix->cpuUsages = (double *)malloc(matrix->size * sizeof(double));
        fread(matrix->cpuUsages, sizeof(double), matrix->size, file);

        free(matrix->countingTimes);
        matrix->countingTimes = (double *)malloc(matrix->size * sizeof(double));
        fread(matrix->countingTimes, sizeof(double), matrix->size, file);
        fclose(file);
    } else {
        printf("File opening error.\n");
    }
}

void printMatrixTimeClass(const matrixTimeClass *matrix) {
    printf("Matrix Size: %d\n", matrix->matrixSize);
    printf("Average Time: %.4f\n", matrix->average);
    printf("Average memory usage: %.2f MB\n", matrix->avgMemoryUsage / 1000);
    printf("Average CPU usage: %.2f%%\n", matrix->avgCPUUsage);
    printf("Min Time: %.3f\n", matrix->min);
    printf("Max Time: %.3f\n", matrix->max);
    printf("Mediana Time: %.3f\n", matrix->mediana);

    if (matrix->size > 0 && matrix->countingTimes != NULL) {
        printf("Counting Times:\n");
        for (int i = 0; i < matrix->size; i++) {
            printf("  Time %d: %.3f\n", i + 1, matrix->countingTimes[i]);
        }
    } else {
        printf("No counting times recorded.\n");
    }
}

#endif // MATRIXCLASS_H
